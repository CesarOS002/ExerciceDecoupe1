<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<nav>
        <ul>
            <a href="index.html"><li><span></span>Accueil</li></a>
            <a href="histoire.html"><li><span></span>Histoire</li></a>
            <a href="plantes.html"><li><span></span>Nos plantes</li></a>
            <a href="contact.html"><li><span></span>Contact</li></a>
        </ul>
    </nav>
</body>
</html>